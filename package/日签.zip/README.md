# 日签 for JSBox

**做一张图，写一段字，记录美好的生活**

### 简介
- 使用本脚本，制作图文日签。
- 提供了网上流行的若干种日签主题模板。
- 可选择文本字体。

### 生成的日签示例

![](https://github.com/bs-2001/riqian-jsbox/raw/master/screenshot/IMG_3188.JPG)

![](https://github.com/bs-2001/riqian-jsbox/raw/master/screenshot/IMG_3192.JPG)

![](https://github.com/bs-2001/riqian-jsbox/raw/master/screenshot/IMG_3215.JPG)

![](https://github.com/bs-2001/riqian-jsbox/raw/master/screenshot/IMG_3219.JPG)

### 界面截图

![](https://github.com/bs-2001/riqian-jsbox/raw/master/screenshot/IMG_3235.PNG)

![](https://github.com/bs-2001/riqian-jsbox/raw/master/screenshot/IMG_3236.PNG)

![](https://github.com/bs-2001/riqian-jsbox/raw/master/screenshot/IMG_3237.PNG)

![](https://github.com/bs-2001/riqian-jsbox/raw/master/screenshot/IMG_3238.PNG)


### 声明
字体版权：虽有公开资料显示我们选用的字体为免费授权，但一般都仅供个人使用，切勿商用！